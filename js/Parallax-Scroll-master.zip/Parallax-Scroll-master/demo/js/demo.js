$(function() {
  
  $(".bg-holder").parallaxScroll({
    friction: 0.5,
    direction: "vertical"
  });
  
});